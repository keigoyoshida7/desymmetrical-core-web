const finite = (v, min, max) =>
  typeof v === "number" && Number.isFinite(v) && v >= min && v <= max;
export function validateState(d, now = Date.now()) {
  if (
    d?.type !== "state" ||
    d.version !== 1 ||
    !finite(d.at, now - 2000, now + 500) ||
    !Array.isArray(d.sources) ||
    d.sources.length > 257 ||
    !finite(d.volume, 0, 0.8)
  )
    throw Error("Invalid or stale state");
  const seen = new Set();
  for (const s of d.sources) {
    if (!Number.isInteger(s.id) || s.id < 1 || s.id > 257 || seen.has(s.id))
      throw Error("Invalid source id");
    seen.add(s.id);
    for (const [k, lo, hi] of [
      ["frequency", 20, 16000],
      ["gain", 0, 0.65],
      ["x", -20, 20],
      ["y", -20, 20],
      ["z", 0, 20],
      ["spread", 0, 1],
      ["reverb", 0, 1],
    ])
      if (!finite(s[k], lo, hi)) throw Error(`Invalid ${k}`);
  }
  if (d.sources.reduce((n, s) => n + s.gain, 0) > 0.651)
    throw Error("Gain sum exceeds headroom");
  if (!Array.isArray(d.speakers) || d.speakers.length !== 13)
    throw Error("Need 13 speaker records");
  d.speakers.forEach((s, i) => {
    if (
      s.id !== i + 1 ||
      !finite(s.x, -20, 20) ||
      !finite(s.y, -20, 20) ||
      !finite(s.z, 0, 20) ||
      !finite(s.gainDb, -60, 12) ||
      !finite(s.delayMs, 0, 1000) ||
      ![-1, 1].includes(s.polarity)
    )
      throw Error("Invalid speaker calibration");
  });
  return d;
}
function oscString(s) {
  const b = Buffer.from(s + "\0");
  return Buffer.concat([b, Buffer.alloc((4 - (b.length % 4)) % 4)]);
}
export function oscMessage(address, args = []) {
  const tags =
    "," +
    args
      .map((v) =>
        typeof v === "string" ? "s" : Number.isInteger(v) ? "i" : "f",
      )
      .join("");
  const parts = [oscString(address), oscString(tags)];
  args.forEach((v, i) => {
    if (tags[i + 1] === "s") parts.push(oscString(v));
    else {
      const b = Buffer.alloc(4);
      tags[i + 1] === "i" ? b.writeInt32BE(v) : b.writeFloatBE(v);
      parts.push(b);
    }
  });
  return Buffer.concat(parts);
}
export function stateMessages(d, sequence = 1) {
  const byId = new Map(d.sources.map((s) => [s.id, s])),
    out = [];
  for (let id = 1; id <= 257; id++) {
    const s = byId.get(id);
    out.push(
      oscMessage(
        "/shadow/voice",
        s
          ? [
              id,
              s.frequency,
              s.gain * d.volume,
              s.x,
              s.y,
              s.z,
              s.spread * 100,
              s.reverb,
            ]
          : [id, 110, 0, 0, 0, 0.319, 0, 0],
      ),
    );
  }
  d.speakers.forEach((s) =>
    out.push(
      oscMessage("/shadow/speaker", [
        s.id,
        s.x,
        s.y,
        s.z,
        s.gainDb,
        s.delayMs,
        s.polarity,
      ]),
    ),
  );
  out.push(oscMessage("/shadow/heartbeat", [sequence]));
  return out;
}

export function parseMaxStatus(packet) {
  let offset=0;
  const string=()=>{const end=packet.indexOf(0,offset);if(end<0)throw Error('Unterminated OSC string');const s=packet.toString('utf8',offset,end);offset=(end+4)&~3;return s;};
  if(string()!=='/shadow/status')throw Error('Not a Max status packet');
  const tags=string();if(!/^,[if]{11}$/.test(tags)||packet.length-offset!==44)throw Error('Invalid Max status');
  const values=[];for(const t of tags.slice(1)){values.push(t==='i'?packet.readInt32BE(offset):packet.readFloatBE(offset));offset+=4;}
  const [sequence,packets,active,rxAlive,prePeak,spatPeak,outPeak,dsp,mode,masterDb,sampleRate]=values;
  if(!values.every(Number.isFinite)||!Number.isInteger(sequence)||sequence<0||packets<0||active<0||active>257||![0,1].includes(rxAlive)||![0,1].includes(dsp)||![0,1].includes(mode)||[prePeak,spatPeak,outPeak].some(x=>x<0||x>4)||masterDb< -90||masterDb>0||sampleRate<0||sampleRate>384000)throw Error('Max status outside ranges');
  return {connected:true,sequence,packets,active,rxAlive:!!rxAlive,prePeak,spatPeak,outPeak,dsp:!!dsp,mode:mode===0?'stereo':'12.1',masterDb,sampleRate};
}
