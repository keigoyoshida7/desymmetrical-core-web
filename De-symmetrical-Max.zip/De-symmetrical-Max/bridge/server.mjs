import { WebSocketServer } from 'ws';
import { createSocket } from 'node:dgram';
import { pathToFileURL } from 'node:url';
import { validateState, stateMessages, oscMessage, parseMaxStatus } from './protocol.mjs';

export function startBridge({port=Number(process.env.SHADOW_BRIDGE_PORT||8788), oscPort=Number(process.env.SHADOW_OSC_PORT||9000), feedbackPort=Number(process.env.SHADOW_FEEDBACK_PORT||9001), onLog=console.log}={}) {
 const allowed=new Set(['http://127.0.0.1:5173','http://localhost:5173','https://desymmetrical-shadow-lab.tender-comet-7546.chatgpt.site','https://keigoyoshida7.github.io',process.env.SHADOW_SITE_ORIGIN].filter(Boolean));
 const udp=createSocket('udp4'), feedback=createSocket('udp4');
 let owner=null,last=0,muted=true,closing=false,sequence=0,maxStatus=null;
 const send=b=>{if(!closing)udp.send(b,oscPort,'127.0.0.1');};
 const mute=()=>{send(oscMessage('/shadow/mute',[1]));muted=true;};
 udp.on('error',e=>onLog(`OSC: ${e.message}`));
 const wss=new WebSocketServer({host:'127.0.0.1',port,maxPayload:256*1024,perMessageDeflate:false,verifyClient:i=>allowed.has(i.origin)});
 const broadcast=d=>{if(owner?.readyState===1)owner.send(JSON.stringify(d));};
 feedback.on('message',(packet,remote)=>{if(remote.address!=='127.0.0.1')return;try{const s=parseMaxStatus(packet);const now=Date.now();maxStatus={...s,receivedAt:now};broadcast({type:'max-status',...s,receivedAt:now,matched:sequence>0&&s.sequence>0&&sequence-s.sequence>=0&&sequence-s.sequence<30&&now-last<2000});}catch{}});
 wss.on('connection',ws=>{
  if(owner?.readyState===1){ws.close(1008,'One controlling UI at a time');return;}owner=ws;let rateAt=0;
  ws.on('message',raw=>{try{const d=JSON.parse(raw);if(d.type==='mute'){mute();return;}const now=Date.now();if(now-rateAt<60)return;rateAt=now;validateState(d,now);sequence=sequence>=2147483646?1:sequence+1;for(const m of stateMessages(d,sequence))send(m);last=now;muted=false;ws.send(JSON.stringify({type:'ack',sources:d.sources.length,sequence,at:now}));}catch(e){mute();if(ws.readyState===1)ws.send(JSON.stringify({type:'error',message:e.message}));}});
  ws.on('close',()=>{if(owner===ws){owner=null;mute();}});
 });
 const watch=setInterval(()=>{if(!muted&&Date.now()-last>1500)mute();if(owner?.readyState===1&&(!maxStatus||Date.now()-maxStatus.receivedAt>1500))broadcast({type:'max-status',connected:false,reason:'Max応答なし'});},500);
 const ready=Promise.all([new Promise((resolve,reject)=>{wss.once('listening',resolve);wss.once('error',reject);}),new Promise((resolve,reject)=>{feedback.once('error',reject);feedback.bind(feedbackPort,'127.0.0.1',resolve);})]).then(()=>{onLog(`Shadow bridge ready: ws://127.0.0.1:${wss.address().port}; Max OSC:${oscPort}; return:${feedback.address().port}`);return{port:wss.address().port,feedbackPort:feedback.address().port};});
 async function close(){if(closing)return;mute();closing=true;clearInterval(watch);for(const c of wss.clients)c.terminate();wss.close();await new Promise(r=>setTimeout(r,50));for(const socket of[udp,feedback])try{socket.close();}catch(e){if(e.code!=='ERR_SOCKET_DGRAM_NOT_RUNNING')throw e;}}
 return{ready,close};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const service=startBridge();service.ready.catch(async e=>{console.error(e.message);await service.close();process.exit(1);});let exiting=false;const stop=async()=>{if(exiting)return;exiting=true;await service.close();process.exit(0);};process.on('SIGINT',stop);process.on('SIGTERM',stop);}
