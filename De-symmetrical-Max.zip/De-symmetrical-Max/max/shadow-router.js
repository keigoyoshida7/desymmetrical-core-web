// Max JS: control and measured telemetry. Audio is synthesized in Max, not streamed PCM.
autowatch = 1;
inlets = 8;
outlets = 10;
var last=0,sequence=0,packets=0,active=0,dsp=0,sr=0,mode=0,master=-24,testUntil=0;
var peaks=[0,0,0],gains=[],watchdog=new Task(check,this);
watchdog.interval=250;watchdog.repeat();
function zero(){for(var i=1;i<=257;i++){gains[i]=0;outlet(1,'setvalue',i,0,50);}active=0;}
function mute(){zero();testUntil=0;}
function ui(k,v){outlet(5,k,v);}
function check(){
 var now=Date.now(),alive=last>0&&now-last<1500;
 if(testUntil&&now>=testUntil){mute();}
 if(!testUntil&&!alive&&active)zero();
 for(var j=0;j<3;j++)ui(['levela','levelb','levelc'][j],20*Math.log(Math.max(dsp?peaks[j]:0,0.000001))/Math.LN10);
 ui('receive',alive?1:0);ui('packets',packets);ui('active',active);ui('test',testUntil?1:0);
 outlet(6,'/shadow/status',sequence,packets,active,alive?1:0,dsp?peaks[0]:0,dsp?peaks[1]:0,dsp?peaks[2]:0,dsp,mode,master,sr);
}
function msg_int(v){number(v);}
function msg_float(v){number(v);}
function number(v){
 if(inlet===2){mute();return;}
 if(inlet===3){sequence=Math.max(0,Math.floor(v));packets++;last=Date.now();active=0;for(var i=1;i<=257;i++)if(gains[i]>0.000001)active++;return;}
 if(inlet>=4&&inlet<=6)peaks[inlet-4]=Math.max(0,Math.abs(v));
}
function list(){
 var a=arrayfromargs(arguments);
 if(inlet===0){
  var id=Math.round(a[0]);if(id<1||id>257||a.length<8)return;
  var f=a[1],g=a[2];if(!isFinite(f)||!isFinite(g)||f<20||f>20000||g<0||g>.52)return;
  testUntil=0;gains[id]=g;
  outlet(0,'setvalue',id,f);outlet(1,'setvalue',id,g,45);
  outlet(2,'/source/'+id+'/xyz',a[3],a[4],a[5]);
  outlet(9,'/source/'+id+'/spread',Math.max(0,Math.min(100,a[6])));
  outlet(9,'/source/'+id+'/reverb/gain',-60+54*Math.max(0,Math.min(1,a[7])));
 }else if(inlet===1){
  var ch=Math.round(a[0]);if(ch<1||ch>13||a.length<7)return;
  if(ch<=12)outlet(2,'/speaker/'+ch+'/xyz',a[1],a[2],a[3]);
  outlet(3,'setvalue',ch,Math.pow(10,a[4]/20)*a[6],50);outlet(4,'/channel/'+ch+'/delay',a[5]);
 }else if(inlet>=4&&inlet<=6){var p=0;for(var j=0;j<a.length;j++)p=Math.max(p,Math.abs(a[j]));peaks[inlet-4]=p;}
 else if(a.length)number(a[0]);
}
function anything(){
 if(inlet!==7)return;
 var a=arrayfromargs(arguments),v=Number(a[0]);
 if(messagename==='dsp'){dsp=v?1:0;ui('dsp',dsp);if(!dsp)peaks=[0,0,0];}
 if(messagename==='samplerate'){sr=Math.max(0,v);ui('samplerate',sr);}
 if(messagename==='mode'){mode=v===1?1:0;outlet(7,mode===0?1:0,mode===1?1:0);ui('mode',mode);}
 if(messagename==='master'){master=Math.max(-70,Math.min(-6,v));outlet(8,Math.pow(10,master/20),100);}
 if(messagename==='testtone'){
  zero();testUntil=Date.now()+5000;gains[1]=.08;active=1;
  outlet(0,'setvalue',1,440);outlet(1,'setvalue',1,.08,100);outlet(2,'/source/1/xyz',0,1,0);outlet(9,'/source/1/reverb/gain',-60);ui('test',1);
 }
 if(messagename==='stop')mute();
}
function loadbang(){
 mute();for(var i=1;i<=12;i++){var angle=2*Math.PI*(i-1)/12;outlet(2,'/speaker/'+i+'/xyz',2*Math.sin(angle),2*Math.cos(angle),i>8?2:0);}
 outlet(7,1,0);outlet(8,Math.pow(10,master/20),50);
}
function notifydeleted(){watchdog.cancel();}
