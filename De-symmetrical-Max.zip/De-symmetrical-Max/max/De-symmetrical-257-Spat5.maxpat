{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 9,
      "minor": 0,
      "revision": 0,
      "architecture": "x64",
      "modernui": 1
    },
    "rect": [
      40,
      55,
      1150,
      750
    ],
    "openinpresentation": 1,
    "bgcolor": [
      0.075,
      0.087,
      0.115,
      1
    ],
    "boxes": [
      {
        "box": {
          "id": "obj-1",
          "maxclass": "comment",
          "text": "DE-SYMMETRICAL / MAX AUDIO",
          "patching_rect": [
            30,
            20,
            880,
            22
          ],
          "fontsize": 26,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            14.6,
            880,
            35.699999999999996
          ]
        }
      },
      {
        "box": {
          "id": "obj-2",
          "maxclass": "comment",
          "text": "影の解析値 → 257音源 → Spat5 → スピーカー  |  ブラウザの音声ボタンは不要です",
          "patching_rect": [
            30,
            65,
            1050,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            47.449999999999996,
            1050,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-3",
          "maxclass": "comment",
          "text": "① 接続を準備 [キー1]",
          "patching_rect": [
            30,
            120,
            240,
            22
          ],
          "fontsize": 18,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            87.6,
            240,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-4",
          "maxclass": "message",
          "text": "接続サービスを起動",
          "patching_rect": [
            30,
            160,
            150,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            30,
            116.8,
            150,
            30
          ]
        }
      },
      {
        "box": {
          "id": "obj-5",
          "maxclass": "newobj",
          "text": "node.script shadow-services.js @autostart 0 @watch 0 @restart 0",
          "patching_rect": [
            20,
            930,
            580,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-6",
          "maxclass": "newobj",
          "text": "route ready failure",
          "patching_rect": [
            20,
            970,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-7",
          "maxclass": "message",
          "text": "script start",
          "patching_rect": [
            300,
            930,
            130,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-8",
          "maxclass": "toggle",
          "text": "",
          "patching_rect": [
            190,
            160,
            30,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            190,
            116.8,
            30,
            30
          ],
          "ignoreclick": 1
        }
      },
      {
        "box": {
          "id": "obj-9",
          "maxclass": "comment",
          "text": "点灯 = 接続サービス起動完了",
          "patching_rect": [
            230,
            158,
            260,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            230,
            115.34,
            260,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-10",
          "maxclass": "message",
          "text": "Web UI を開く",
          "patching_rect": [
            30,
            205,
            190,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            30,
            149.65,
            190,
            30
          ]
        }
      },
      {
        "box": {
          "id": "obj-11",
          "maxclass": "message",
          "text": "; max launchbrowser http://127.0.0.1:5173/?max=1",
          "patching_rect": [
            20,
            1010,
            510,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-12",
          "maxclass": "comment",
          "text": "Webで「Maxへ接続」→ 入力を選ぶ",
          "patching_rect": [
            235,
            203,
            300,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            235,
            148.19,
            300,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-13",
          "maxclass": "newobj",
          "text": "print shadow-services",
          "patching_rect": [
            500,
            970,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-14",
          "maxclass": "comment",
          "text": "② 出力先を選ぶ [キー2]",
          "patching_rect": [
            590,
            120,
            260,
            22
          ],
          "fontsize": 18,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            590,
            87.6,
            260,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-15",
          "maxclass": "message",
          "text": "オーディオ設定",
          "patching_rect": [
            590,
            160,
            190,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            590,
            116.8,
            190,
            30
          ]
        }
      },
      {
        "box": {
          "id": "obj-16",
          "maxclass": "message",
          "text": "open",
          "patching_rect": [
            590,
            930,
            100,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-17",
          "maxclass": "comment",
          "text": "Audio Statusで内蔵出力などを選択。\n12.1ch使用時はI/O Mappingsも確認。",
          "patching_rect": [
            590,
            200,
            490,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            590,
            146,
            490,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-18",
          "maxclass": "comment",
          "text": "③ DSP を ON [キー3]",
          "patching_rect": [
            30,
            280,
            240,
            22
          ],
          "fontsize": 18,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            204.4,
            240,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-19",
          "maxclass": "toggle",
          "text": "",
          "patching_rect": [
            30,
            320,
            34,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            30,
            233.6,
            34,
            30
          ]
        }
      },
      {
        "box": {
          "id": "obj-20",
          "maxclass": "comment",
          "text": "クリックで音声処理を開始",
          "patching_rect": [
            80,
            316,
            350,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            80,
            230.68,
            350,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-21",
          "maxclass": "toggle",
          "text": "",
          "patching_rect": [
            355,
            320,
            30,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            355,
            233.6,
            30,
            30
          ],
          "ignoreclick": 1
        }
      },
      {
        "box": {
          "id": "obj-22",
          "maxclass": "comment",
          "text": "実際のDSP状態",
          "patching_rect": [
            395,
            316,
            180,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            395,
            230.68,
            180,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-23",
          "maxclass": "comment",
          "text": "④ 出力モード / 音量",
          "patching_rect": [
            590,
            280,
            390,
            22
          ],
          "fontsize": 18,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            590,
            204.4,
            390,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-24",
          "maxclass": "umenu",
          "text": "",
          "patching_rect": [
            590,
            320,
            230,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            590,
            233.6,
            230,
            30
          ],
          "items": [
            "ステレオ試聴 (Mac)",
            ",",
            "12.1ch (13 outputs)"
          ]
        }
      },
      {
        "box": {
          "id": "obj-25",
          "maxclass": "flonum",
          "text": "",
          "patching_rect": [
            840,
            320,
            75,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            840,
            233.6,
            75,
            30
          ],
          "minimum": -70,
          "maximum": -6,
          "format": 6
        }
      },
      {
        "box": {
          "id": "obj-26",
          "maxclass": "comment",
          "text": "dB / 初期 -24",
          "patching_rect": [
            930,
            316,
            190,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            930,
            230.68,
            190,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-27",
          "maxclass": "comment",
          "text": "ステレオはSpat5出力をL/Rへ縮約。\n音量はWeb側の音量とこのマスターの両方が反映されます。",
          "patching_rect": [
            590,
            365,
            500,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            590,
            266.45,
            500,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-28",
          "maxclass": "comment",
          "text": "⑤ 経路をテスト [キー5]",
          "patching_rect": [
            30,
            415,
            300,
            22
          ],
          "fontsize": 18,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            302.95,
            300,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-29",
          "maxclass": "message",
          "text": "5秒テスト音",
          "patching_rect": [
            30,
            455,
            170,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            30,
            332.15,
            170,
            30
          ]
        }
      },
      {
        "box": {
          "id": "obj-30",
          "maxclass": "message",
          "text": "testtone 1",
          "patching_rect": [
            20,
            1050,
            120,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-31",
          "maxclass": "toggle",
          "text": "",
          "patching_rect": [
            220,
            455,
            30,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            220,
            332.15,
            30,
            30
          ],
          "ignoreclick": 1
        }
      },
      {
        "box": {
          "id": "obj-32",
          "maxclass": "comment",
          "text": "440 Hz・小音量。Web入力が届くとテストを終了。\nテスト音は「Web受信」の確認には使いません。",
          "patching_rect": [
            270,
            450,
            610,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            270,
            328.5,
            610,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-33",
          "maxclass": "message",
          "text": "STOP / 消音",
          "patching_rect": [
            900,
            452,
            195,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            900,
            329.96,
            195,
            30
          ]
        }
      },
      {
        "box": {
          "id": "obj-34",
          "maxclass": "message",
          "text": "stop 1",
          "patching_rect": [
            800,
            1050,
            100,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-35",
          "maxclass": "message",
          "text": "0",
          "patching_rect": [
            930,
            1050,
            40,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-36",
          "maxclass": "comment",
          "text": "受信と音声を確認",
          "patching_rect": [
            30,
            525,
            600,
            22
          ],
          "fontsize": 20,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            383.25,
            600,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-37",
          "maxclass": "toggle",
          "text": "",
          "patching_rect": [
            30,
            580,
            30,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            30,
            423.4,
            30,
            30
          ],
          "ignoreclick": 1
        }
      },
      {
        "box": {
          "id": "obj-38",
          "maxclass": "comment",
          "text": "Web受信",
          "patching_rect": [
            75,
            578,
            160,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            75,
            421.94,
            160,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-39",
          "maxclass": "number",
          "text": "",
          "patching_rect": [
            210,
            580,
            110,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            210,
            423.4,
            110,
            30
          ],
          "ignoreclick": 1
        }
      },
      {
        "box": {
          "id": "obj-40",
          "maxclass": "comment",
          "text": "受信フレーム",
          "patching_rect": [
            330,
            578,
            160,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            330,
            421.94,
            160,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-41",
          "maxclass": "number",
          "text": "",
          "patching_rect": [
            485,
            580,
            80,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            485,
            423.4,
            80,
            30
          ],
          "ignoreclick": 1
        }
      },
      {
        "box": {
          "id": "obj-42",
          "maxclass": "comment",
          "text": "有効音源 / 最大257",
          "patching_rect": [
            575,
            578,
            260,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            575,
            421.94,
            260,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-43",
          "maxclass": "number",
          "text": "",
          "patching_rect": [
            870,
            580,
            100,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            870,
            423.4,
            100,
            30
          ],
          "ignoreclick": 1
        }
      },
      {
        "box": {
          "id": "obj-44",
          "maxclass": "comment",
          "text": "Hz",
          "patching_rect": [
            982,
            578,
            90,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            982,
            421.94,
            90,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-45",
          "maxclass": "comment",
          "text": "A 音源生成（絶対値合計）",
          "patching_rect": [
            30,
            640,
            330,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            467.2,
            330,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-46",
          "maxclass": "comment",
          "text": "B Spat5処理後",
          "patching_rect": [
            395,
            640,
            330,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            395,
            467.2,
            330,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-47",
          "maxclass": "comment",
          "text": "C 出力直前（選択モード）",
          "patching_rect": [
            760,
            640,
            350,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            760,
            467.2,
            350,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-48",
          "maxclass": "flonum",
          "text": "",
          "patching_rect": [
            30,
            682,
            120,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            30,
            497.86,
            120,
            30
          ],
          "ignoreclick": 1,
          "format": 6
        }
      },
      {
        "box": {
          "id": "obj-49",
          "maxclass": "comment",
          "text": "peak dBFS",
          "patching_rect": [
            165,
            680,
            170,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            165,
            496.4,
            170,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-50",
          "maxclass": "flonum",
          "text": "",
          "patching_rect": [
            395,
            682,
            120,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            395,
            497.86,
            120,
            30
          ],
          "ignoreclick": 1,
          "format": 6
        }
      },
      {
        "box": {
          "id": "obj-51",
          "maxclass": "comment",
          "text": "peak dBFS",
          "patching_rect": [
            530,
            680,
            170,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            530,
            496.4,
            170,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-52",
          "maxclass": "flonum",
          "text": "",
          "patching_rect": [
            760,
            682,
            120,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            760,
            497.86,
            120,
            30
          ],
          "ignoreclick": 1,
          "format": 6
        }
      },
      {
        "box": {
          "id": "obj-53",
          "maxclass": "comment",
          "text": "peak dBFS",
          "patching_rect": [
            895,
            680,
            170,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            895,
            496.4,
            170,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-54",
          "maxclass": "comment",
          "text": "13チャンネルのSpat5出力（校正後 / マスター前）",
          "patching_rect": [
            30,
            730,
            700,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            532.9,
            700,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-55",
          "maxclass": "comment",
          "text": "受信が点灯 → A/B/Cの数値とメーターが動けば、Maxの出力直前まで信号が到達しています。\nCが動いても聞こえない時は②で出力デバイス・マッピング・スピーカーの音量を確認。-120 = 無音。",
          "patching_rect": [
            30,
            840,
            1060,
            22
          ],
          "fontsize": 14,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            613.1999999999999,
            1060,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-56",
          "maxclass": "newobj",
          "text": "spat5.osc.udpreceive @port 9000",
          "patching_rect": [
            20,
            1150,
            300,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-57",
          "maxclass": "newobj",
          "text": "spat5.osc.route /shadow/voice /shadow/speaker /shadow/mute /shadow/heartbeat",
          "patching_rect": [
            20,
            1190,
            650,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-58",
          "maxclass": "newobj",
          "text": "js shadow-router.js",
          "patching_rect": [
            20,
            1230,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-59",
          "maxclass": "newobj",
          "text": "prepend mode",
          "patching_rect": [
            450,
            1050,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-60",
          "maxclass": "newobj",
          "text": "prepend master",
          "patching_rect": [
            650,
            1090,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-61",
          "maxclass": "newobj",
          "text": "loadbang",
          "patching_rect": [
            1030,
            1050,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-62",
          "maxclass": "message",
          "text": "-24",
          "patching_rect": [
            1030,
            1090,
            60,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-63",
          "maxclass": "newobj",
          "text": "route receive packets active test dsp samplerate levela levelb levelc",
          "patching_rect": [
            20,
            1280,
            480,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-64",
          "maxclass": "newobj",
          "text": "spat5.osc.udpsend @ip 127.0.0.1 @port 9001",
          "patching_rect": [
            20,
            1320,
            440,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-65",
          "maxclass": "newobj",
          "text": "mc.cycle~ 110 @chans 257",
          "patching_rect": [
            20,
            1380,
            240,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-66",
          "maxclass": "newobj",
          "text": "mc.line~ 0 @chans 257",
          "patching_rect": [
            280,
            1380,
            230,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-67",
          "maxclass": "newobj",
          "text": "mc.*~ 0",
          "patching_rect": [
            20,
            1420,
            130,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-68",
          "maxclass": "newobj",
          "text": "spat5.oper @initwith \"/source/number 257, /speaker/number 12, /room/number 1\" @internals 8",
          "patching_rect": [
            20,
            1500,
            750,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-69",
          "maxclass": "newobj",
          "text": "spat5.spat~ @inputs 257 @outputs 12 @internals 8 @rooms 1 @mc 1 @initwith \"/panning/type knn\"",
          "patching_rect": [
            20,
            1540,
            850,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-70",
          "maxclass": "newobj",
          "text": "mc.mixdown~ 1 @autogain 0",
          "patching_rect": [
            550,
            1380,
            270,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-71",
          "maxclass": "newobj",
          "text": "mc.unpack~ 1",
          "patching_rect": [
            550,
            1420,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-72",
          "maxclass": "newobj",
          "text": "lores~ 90 0.6",
          "patching_rect": [
            550,
            1460,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-73",
          "maxclass": "newobj",
          "text": "mc.abs~",
          "patching_rect": [
            800,
            1380,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-74",
          "maxclass": "newobj",
          "text": "mc.mixdown~ 1 @autogain 0",
          "patching_rect": [
            800,
            1420,
            270,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-75",
          "maxclass": "newobj",
          "text": "mc.unpack~ 1",
          "patching_rect": [
            1020,
            2320,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-76",
          "maxclass": "newobj",
          "text": "pak 0.",
          "patching_rect": [
            1020,
            2400,
            550,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-77",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            20,
            2360,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-78",
          "maxclass": "newobj",
          "text": "mc.unpack~ 12",
          "patching_rect": [
            20,
            1600,
            400,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-79",
          "maxclass": "newobj",
          "text": "mc.pack~ 13",
          "patching_rect": [
            20,
            1650,
            450,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-80",
          "maxclass": "newobj",
          "text": "spat5.delay~ @channels 13 @mc 1",
          "patching_rect": [
            20,
            1690,
            300,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-81",
          "maxclass": "newobj",
          "text": "mc.line~ 1 @chans 13",
          "patching_rect": [
            340,
            1690,
            240,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-82",
          "maxclass": "newobj",
          "text": "mc.*~ 1",
          "patching_rect": [
            20,
            1730,
            130,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-83",
          "maxclass": "newobj",
          "text": "mc.unpack~ 12",
          "patching_rect": [
            1270,
            2450,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-84",
          "maxclass": "newobj",
          "text": "pak 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0.",
          "patching_rect": [
            1270,
            2530,
            550,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-85",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            20,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-86",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            135,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-87",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            250,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-88",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            365,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-89",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            480,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-90",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            595,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-91",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            710,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-92",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            825,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-93",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            940,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-94",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            1055,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-95",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            1170,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-96",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            1285,
            2490,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-97",
          "maxclass": "newobj",
          "text": "mc.unpack~ 13",
          "patching_rect": [
            20,
            1780,
            450,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-98",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            30,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            30,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-99",
          "maxclass": "comment",
          "text": "1",
          "patching_rect": [
            30,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            30,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-100",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            112,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            112,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-101",
          "maxclass": "comment",
          "text": "2",
          "patching_rect": [
            112,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            112,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-102",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            194,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            194,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-103",
          "maxclass": "comment",
          "text": "3",
          "patching_rect": [
            194,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            194,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-104",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            276,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            276,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-105",
          "maxclass": "comment",
          "text": "4",
          "patching_rect": [
            276,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            276,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-106",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            358,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            358,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-107",
          "maxclass": "comment",
          "text": "5",
          "patching_rect": [
            358,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            358,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-108",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            440,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            440,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-109",
          "maxclass": "comment",
          "text": "6",
          "patching_rect": [
            440,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            440,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-110",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            522,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            522,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-111",
          "maxclass": "comment",
          "text": "7",
          "patching_rect": [
            522,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            522,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-112",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            604,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            604,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-113",
          "maxclass": "comment",
          "text": "8",
          "patching_rect": [
            604,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            604,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-114",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            686,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            686,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-115",
          "maxclass": "comment",
          "text": "9",
          "patching_rect": [
            686,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            686,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-116",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            768,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            768,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-117",
          "maxclass": "comment",
          "text": "10",
          "patching_rect": [
            768,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            768,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-118",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            850,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            850,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-119",
          "maxclass": "comment",
          "text": "11",
          "patching_rect": [
            850,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            850,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-120",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            932,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            932,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-121",
          "maxclass": "comment",
          "text": "12",
          "patching_rect": [
            932,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            932,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-122",
          "maxclass": "meter~",
          "text": "",
          "patching_rect": [
            1014,
            775,
            66,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            1014,
            565.75,
            66,
            24
          ]
        }
      },
      {
        "box": {
          "id": "obj-123",
          "maxclass": "comment",
          "text": "13 SUB",
          "patching_rect": [
            1014,
            802,
            72,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            1014,
            585.46,
            72,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-124",
          "maxclass": "newobj",
          "text": "line~ 0.",
          "patching_rect": [
            20,
            3000,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-125",
          "maxclass": "newobj",
          "text": "mc.*~ 0.",
          "patching_rect": [
            250,
            3000,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-126",
          "maxclass": "newobj",
          "text": "mc.clip~ -0.85 0.85",
          "patching_rect": [
            480,
            3000,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-127",
          "maxclass": "newobj",
          "text": "unpack 0. 0.",
          "patching_rect": [
            20,
            3070,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-128",
          "maxclass": "newobj",
          "text": "mc.mixdown~ 2 @autogain 1",
          "patching_rect": [
            250,
            3070,
            260,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-129",
          "maxclass": "newobj",
          "text": "mc.*~ 0.",
          "patching_rect": [
            550,
            3070,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-130",
          "maxclass": "newobj",
          "text": "mc.*~ 0.",
          "patching_rect": [
            780,
            3070,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-131",
          "maxclass": "newobj",
          "text": "mc.unpack~ 2",
          "patching_rect": [
            250,
            3120,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-132",
          "maxclass": "newobj",
          "text": "mc.unpack~ 13",
          "patching_rect": [
            780,
            3120,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-133",
          "maxclass": "newobj",
          "text": "mc.pack~ 13",
          "patching_rect": [
            500,
            3240,
            400,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-134",
          "maxclass": "newobj",
          "text": "+~",
          "patching_rect": [
            200,
            3180,
            70,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-135",
          "maxclass": "newobj",
          "text": "+~",
          "patching_rect": [
            290,
            3180,
            70,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-136",
          "maxclass": "newobj",
          "text": "mc.dac~ 1 2 3 4 5 6 7 8 9 10 11 12 13",
          "patching_rect": [
            500,
            3290,
            440,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-137",
          "maxclass": "newobj",
          "text": "mc.unpack~ 13",
          "patching_rect": [
            1520,
            2580,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-138",
          "maxclass": "newobj",
          "text": "pak 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0.",
          "patching_rect": [
            1520,
            2660,
            550,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-139",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            20,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-140",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            135,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-141",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            250,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-142",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            365,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-143",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            480,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-144",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            595,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-145",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            710,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-146",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            825,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-147",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            940,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-148",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            1055,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-149",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            1170,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-150",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            1285,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-151",
          "maxclass": "newobj",
          "text": "peakamp~ 100",
          "patching_rect": [
            1400,
            2620,
            110,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-152",
          "maxclass": "newobj",
          "text": "dspstate~",
          "patching_rect": [
            20,
            3330,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-153",
          "maxclass": "newobj",
          "text": "qmetro 500",
          "patching_rect": [
            20,
            3370,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-154",
          "maxclass": "message",
          "text": "1",
          "patching_rect": [
            150,
            3370,
            40,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-155",
          "maxclass": "newobj",
          "text": "prepend dsp",
          "patching_rect": [
            20,
            3410,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-156",
          "maxclass": "newobj",
          "text": "prepend samplerate",
          "patching_rect": [
            250,
            3410,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-157",
          "maxclass": "newobj",
          "text": "adstatus cpu",
          "patching_rect": [
            500,
            3410,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-158",
          "maxclass": "flonum",
          "text": "",
          "patching_rect": [
            900,
            925,
            80,
            22
          ],
          "fontsize": 15,
          "presentation": 1,
          "presentation_rect": [
            900,
            675.25,
            80,
            30
          ],
          "ignoreclick": 1,
          "format": 6
        }
      },
      {
        "box": {
          "id": "obj-159",
          "maxclass": "comment",
          "text": "DSP負荷 %",
          "patching_rect": [
            1000,
            925,
            120,
            22
          ],
          "fontsize": 12,
          "textcolor": [
            0.85,
            0.87,
            0.91,
            1
          ],
          "presentation": 1,
          "presentation_rect": [
            1000,
            675.25,
            120,
            37.4
          ]
        }
      },
      {
        "box": {
          "id": "obj-160",
          "maxclass": "newobj",
          "text": "key",
          "patching_rect": [
            20,
            3500,
            220,
            22
          ]
        }
      },
      {
        "box": {
          "id": "obj-161",
          "maxclass": "newobj",
          "text": "sel 49 50 51 53 48 27",
          "patching_rect": [
            180,
            3500,
            270,
            22
          ]
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "source": [
            "obj-4",
            0
          ],
          "destination": [
            "obj-7",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-7",
            0
          ],
          "destination": [
            "obj-5",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-5",
            0
          ],
          "destination": [
            "obj-6",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-6",
            0
          ],
          "destination": [
            "obj-8",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-10",
            0
          ],
          "destination": [
            "obj-11",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-5",
            1
          ],
          "destination": [
            "obj-13",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-6",
            1
          ],
          "destination": [
            "obj-13",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-15",
            0
          ],
          "destination": [
            "obj-16",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-29",
            0
          ],
          "destination": [
            "obj-30",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-33",
            0
          ],
          "destination": [
            "obj-34",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-33",
            0
          ],
          "destination": [
            "obj-35",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-35",
            0
          ],
          "destination": [
            "obj-19",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-56",
            0
          ],
          "destination": [
            "obj-57",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-57",
            0
          ],
          "destination": [
            "obj-58",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-57",
            1
          ],
          "destination": [
            "obj-58",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-57",
            2
          ],
          "destination": [
            "obj-58",
            2
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-57",
            3
          ],
          "destination": [
            "obj-58",
            3
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-30",
            0
          ],
          "destination": [
            "obj-58",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-34",
            0
          ],
          "destination": [
            "obj-58",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-24",
            0
          ],
          "destination": [
            "obj-59",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-59",
            0
          ],
          "destination": [
            "obj-58",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-25",
            0
          ],
          "destination": [
            "obj-60",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-60",
            0
          ],
          "destination": [
            "obj-58",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-61",
            0
          ],
          "destination": [
            "obj-62",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-62",
            0
          ],
          "destination": [
            "obj-25",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            5
          ],
          "destination": [
            "obj-63",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            0
          ],
          "destination": [
            "obj-37",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            1
          ],
          "destination": [
            "obj-39",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            2
          ],
          "destination": [
            "obj-41",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            3
          ],
          "destination": [
            "obj-31",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            4
          ],
          "destination": [
            "obj-21",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            5
          ],
          "destination": [
            "obj-43",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            6
          ],
          "destination": [
            "obj-48",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            7
          ],
          "destination": [
            "obj-50",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-63",
            8
          ],
          "destination": [
            "obj-52",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            6
          ],
          "destination": [
            "obj-64",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            0
          ],
          "destination": [
            "obj-65",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            1
          ],
          "destination": [
            "obj-66",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-65",
            0
          ],
          "destination": [
            "obj-67",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-66",
            0
          ],
          "destination": [
            "obj-67",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            2
          ],
          "destination": [
            "obj-68",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-68",
            0
          ],
          "destination": [
            "obj-69",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-67",
            0
          ],
          "destination": [
            "obj-69",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            9
          ],
          "destination": [
            "obj-69",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-61",
            0
          ],
          "destination": [
            "obj-68",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-67",
            0
          ],
          "destination": [
            "obj-70",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-70",
            0
          ],
          "destination": [
            "obj-71",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-71",
            0
          ],
          "destination": [
            "obj-72",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-67",
            0
          ],
          "destination": [
            "obj-73",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-73",
            0
          ],
          "destination": [
            "obj-74",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-74",
            0
          ],
          "destination": [
            "obj-75",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-75",
            0
          ],
          "destination": [
            "obj-77",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-77",
            0
          ],
          "destination": [
            "obj-76",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-76",
            0
          ],
          "destination": [
            "obj-58",
            4
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-69",
            0
          ],
          "destination": [
            "obj-78",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            0
          ],
          "destination": [
            "obj-79",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            1
          ],
          "destination": [
            "obj-79",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            2
          ],
          "destination": [
            "obj-79",
            2
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            3
          ],
          "destination": [
            "obj-79",
            3
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            4
          ],
          "destination": [
            "obj-79",
            4
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            5
          ],
          "destination": [
            "obj-79",
            5
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            6
          ],
          "destination": [
            "obj-79",
            6
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            7
          ],
          "destination": [
            "obj-79",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            8
          ],
          "destination": [
            "obj-79",
            8
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            9
          ],
          "destination": [
            "obj-79",
            9
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            10
          ],
          "destination": [
            "obj-79",
            10
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-78",
            11
          ],
          "destination": [
            "obj-79",
            11
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-72",
            0
          ],
          "destination": [
            "obj-79",
            12
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-79",
            0
          ],
          "destination": [
            "obj-80",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            4
          ],
          "destination": [
            "obj-80",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            3
          ],
          "destination": [
            "obj-81",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-80",
            0
          ],
          "destination": [
            "obj-82",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-81",
            0
          ],
          "destination": [
            "obj-82",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-69",
            0
          ],
          "destination": [
            "obj-83",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            0
          ],
          "destination": [
            "obj-85",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-85",
            0
          ],
          "destination": [
            "obj-84",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            1
          ],
          "destination": [
            "obj-86",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-86",
            0
          ],
          "destination": [
            "obj-84",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            2
          ],
          "destination": [
            "obj-87",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-87",
            0
          ],
          "destination": [
            "obj-84",
            2
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            3
          ],
          "destination": [
            "obj-88",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-88",
            0
          ],
          "destination": [
            "obj-84",
            3
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            4
          ],
          "destination": [
            "obj-89",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-89",
            0
          ],
          "destination": [
            "obj-84",
            4
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            5
          ],
          "destination": [
            "obj-90",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-90",
            0
          ],
          "destination": [
            "obj-84",
            5
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            6
          ],
          "destination": [
            "obj-91",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-91",
            0
          ],
          "destination": [
            "obj-84",
            6
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            7
          ],
          "destination": [
            "obj-92",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-92",
            0
          ],
          "destination": [
            "obj-84",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            8
          ],
          "destination": [
            "obj-93",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-93",
            0
          ],
          "destination": [
            "obj-84",
            8
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            9
          ],
          "destination": [
            "obj-94",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-94",
            0
          ],
          "destination": [
            "obj-84",
            9
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            10
          ],
          "destination": [
            "obj-95",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-95",
            0
          ],
          "destination": [
            "obj-84",
            10
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-83",
            11
          ],
          "destination": [
            "obj-96",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-96",
            0
          ],
          "destination": [
            "obj-84",
            11
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-84",
            0
          ],
          "destination": [
            "obj-58",
            5
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-82",
            0
          ],
          "destination": [
            "obj-97",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            0
          ],
          "destination": [
            "obj-98",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            1
          ],
          "destination": [
            "obj-100",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            2
          ],
          "destination": [
            "obj-102",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            3
          ],
          "destination": [
            "obj-104",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            4
          ],
          "destination": [
            "obj-106",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            5
          ],
          "destination": [
            "obj-108",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            6
          ],
          "destination": [
            "obj-110",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            7
          ],
          "destination": [
            "obj-112",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            8
          ],
          "destination": [
            "obj-114",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            9
          ],
          "destination": [
            "obj-116",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            10
          ],
          "destination": [
            "obj-118",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            11
          ],
          "destination": [
            "obj-120",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-97",
            12
          ],
          "destination": [
            "obj-122",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            8
          ],
          "destination": [
            "obj-124",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-82",
            0
          ],
          "destination": [
            "obj-125",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-124",
            0
          ],
          "destination": [
            "obj-125",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-125",
            0
          ],
          "destination": [
            "obj-126",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-58",
            7
          ],
          "destination": [
            "obj-127",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-126",
            0
          ],
          "destination": [
            "obj-128",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-128",
            0
          ],
          "destination": [
            "obj-129",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-126",
            0
          ],
          "destination": [
            "obj-130",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-127",
            0
          ],
          "destination": [
            "obj-129",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-127",
            1
          ],
          "destination": [
            "obj-130",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-129",
            0
          ],
          "destination": [
            "obj-131",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-130",
            0
          ],
          "destination": [
            "obj-132",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-131",
            0
          ],
          "destination": [
            "obj-134",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            0
          ],
          "destination": [
            "obj-134",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-134",
            0
          ],
          "destination": [
            "obj-133",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-131",
            1
          ],
          "destination": [
            "obj-135",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            1
          ],
          "destination": [
            "obj-135",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-135",
            0
          ],
          "destination": [
            "obj-133",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            2
          ],
          "destination": [
            "obj-133",
            2
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            3
          ],
          "destination": [
            "obj-133",
            3
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            4
          ],
          "destination": [
            "obj-133",
            4
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            5
          ],
          "destination": [
            "obj-133",
            5
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            6
          ],
          "destination": [
            "obj-133",
            6
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            7
          ],
          "destination": [
            "obj-133",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            8
          ],
          "destination": [
            "obj-133",
            8
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            9
          ],
          "destination": [
            "obj-133",
            9
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            10
          ],
          "destination": [
            "obj-133",
            10
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            11
          ],
          "destination": [
            "obj-133",
            11
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-132",
            12
          ],
          "destination": [
            "obj-133",
            12
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-133",
            0
          ],
          "destination": [
            "obj-136",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-16",
            0
          ],
          "destination": [
            "obj-136",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-19",
            0
          ],
          "destination": [
            "obj-136",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-133",
            0
          ],
          "destination": [
            "obj-137",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            0
          ],
          "destination": [
            "obj-139",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-139",
            0
          ],
          "destination": [
            "obj-138",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            1
          ],
          "destination": [
            "obj-140",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-140",
            0
          ],
          "destination": [
            "obj-138",
            1
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            2
          ],
          "destination": [
            "obj-141",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-141",
            0
          ],
          "destination": [
            "obj-138",
            2
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            3
          ],
          "destination": [
            "obj-142",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-142",
            0
          ],
          "destination": [
            "obj-138",
            3
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            4
          ],
          "destination": [
            "obj-143",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-143",
            0
          ],
          "destination": [
            "obj-138",
            4
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            5
          ],
          "destination": [
            "obj-144",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-144",
            0
          ],
          "destination": [
            "obj-138",
            5
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            6
          ],
          "destination": [
            "obj-145",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-145",
            0
          ],
          "destination": [
            "obj-138",
            6
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            7
          ],
          "destination": [
            "obj-146",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-146",
            0
          ],
          "destination": [
            "obj-138",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            8
          ],
          "destination": [
            "obj-147",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-147",
            0
          ],
          "destination": [
            "obj-138",
            8
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            9
          ],
          "destination": [
            "obj-148",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-148",
            0
          ],
          "destination": [
            "obj-138",
            9
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            10
          ],
          "destination": [
            "obj-149",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-149",
            0
          ],
          "destination": [
            "obj-138",
            10
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            11
          ],
          "destination": [
            "obj-150",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-150",
            0
          ],
          "destination": [
            "obj-138",
            11
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-137",
            12
          ],
          "destination": [
            "obj-151",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-151",
            0
          ],
          "destination": [
            "obj-138",
            12
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-138",
            0
          ],
          "destination": [
            "obj-58",
            6
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-61",
            0
          ],
          "destination": [
            "obj-154",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-154",
            0
          ],
          "destination": [
            "obj-153",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-153",
            0
          ],
          "destination": [
            "obj-152",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-152",
            0
          ],
          "destination": [
            "obj-155",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-152",
            1
          ],
          "destination": [
            "obj-156",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-155",
            0
          ],
          "destination": [
            "obj-58",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-156",
            0
          ],
          "destination": [
            "obj-58",
            7
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-153",
            0
          ],
          "destination": [
            "obj-157",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-157",
            0
          ],
          "destination": [
            "obj-158",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-160",
            0
          ],
          "destination": [
            "obj-161",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-161",
            0
          ],
          "destination": [
            "obj-4",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-161",
            1
          ],
          "destination": [
            "obj-15",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-161",
            2
          ],
          "destination": [
            "obj-19",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-161",
            3
          ],
          "destination": [
            "obj-29",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-161",
            4
          ],
          "destination": [
            "obj-33",
            0
          ]
        }
      },
      {
        "patchline": {
          "source": [
            "obj-161",
            5
          ],
          "destination": [
            "obj-33",
            0
          ]
        }
      }
    ],
    "dependency_cache": [
      {
        "name": "shadow-router.js",
        "type": "TEXT",
        "implicit": 1
      },
      {
        "name": "shadow-services.js",
        "type": "TEXT",
        "implicit": 1
      }
    ]
  }
}
