// Runs inside Node for Max. No terminal or global Node installation is needed.
const max = require('max-api');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
let services=[], stopping=false;
const startup=(async()=>{
 try{
  const {startWebServer}=await import(pathToFileURL(path.resolve(__dirname,'../server.mjs')).href);
  const {startBridge}=await import(pathToFileURL(path.resolve(__dirname,'../bridge/server.mjs')).href);
  const log=message=>max.post(message);
  const web=startWebServer({onLog:log}),bridge=startBridge({onLog:log});services=[web,bridge];
  await Promise.all(services.map(s=>s.ready));
  if(!stopping)max.outlet('ready',1);
 }catch(error){max.post('Shadow services: '+error.message);max.outlet('failure',error.message);await Promise.allSettled(services.map(s=>s.close()));setTimeout(()=>process.exit(1),100);}
})();
max.addHandler('stop',async()=>{stopping=true;await startup;await Promise.allSettled(services.map(s=>s.close()));max.outlet('ready',0);});
